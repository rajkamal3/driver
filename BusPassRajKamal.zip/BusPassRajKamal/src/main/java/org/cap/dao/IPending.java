package org.cap.dao;

import java.util.List;

import org.cap.bean.BusBean;
import org.cap.bean.TransactionBean;

public interface IPending {
	public List<BusBean> pendingDetails();
	public abstract List<BusBean> pendingDetailsOfEmp(String empid);
	public abstract Integer transaction(TransactionBean transaction);

}
